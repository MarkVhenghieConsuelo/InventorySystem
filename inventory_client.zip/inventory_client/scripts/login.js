function submitForm(event){
    event.preventDefault();
    window.location.href = "../pages/product.html";
}